"""app.py - lance Leeks Downloader après avoir vérifié que tout est en place."""
import importlib
import importlib.util
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox

import core

APP_NAME = "Leeks Downloader"

# module Python -> nom du paquet pip
MODULES = {"PIL": "Pillow", "yt_dlp": "yt-dlp", "spotdl": "spotdl"}

# images attendues dans le dossier assets (png, jpg, jpeg, webp ou ico)
ASSETS_WANTED = {
    "background": "fond de l'application",
    "title": "titre",
    "icon": "icône de la fenêtre",
    "return": "bouton « Relancer une recherche »",
    "croix": "bouton Arrêter",
    "tiktok": "logo TikTok",
    "spotify": "logo Spotify",
    "youtube": "logo YouTube",
}


def missing_modules():
    return [pip for mod, pip in MODULES.items() if importlib.util.find_spec(mod) is None]


def preflight():
    root = tk.Tk()
    root.withdraw()
    try:
        # 1) modules Python
        missing = missing_modules()
        if missing:
            ask = messagebox.askyesno(
                APP_NAME,
                "Modules Python manquants :\n  - " + "\n  - ".join(missing) +
                "\n\nLes installer maintenant ?")
            if not ask:
                return False
            r = subprocess.run([sys.executable, "-m", "pip", "install", *missing])
            importlib.invalidate_caches()
            if r.returncode != 0 or missing_modules():
                messagebox.showerror(
                    APP_NAME,
                    "L'installation a échoué.\nEssaie à la main :\n\n"
                    f"pip install {' '.join(missing)}")
                return False

        # 2) FFmpeg (conversion mp3, fusion vidéo/audio, métadonnées)
        if not core.ffmpeg_ok():
            messagebox.showerror(
                APP_NAME,
                "FFmpeg est introuvable.\n\nInstalle-le avec :\n    winget install Gyan.FFmpeg\n\n"
                "puis ferme et rouvre ton terminal avant de relancer l'app.")
            return False

        # 3) images (l'app se lance quand même, avec un design par défaut)
        absent = [f"  - {stem}  ({label})" for stem, label in ASSETS_WANTED.items()
                  if core.find_asset(stem) is None]
        if absent:
            messagebox.showwarning(
                APP_NAME,
                f"Images introuvables dans :\n{core.ASSETS}\n\n" + "\n".join(absent) +
                "\n\nFormats acceptés : png, jpg, jpeg, webp, ico.\n"
                "L'app se lance quand même avec un design par défaut.")
        return True
    finally:
        root.destroy()


def main():
    if not preflight():
        return
    import gui          # importé seulement maintenant : Pillow est garanti présent
    gui.run()


if __name__ == "__main__":
    main()
