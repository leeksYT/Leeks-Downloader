"""core.py - logique de Leeks Downloader (aucune interface ici)."""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

BASE = Path(__file__).resolve().parent
ASSETS = BASE / "assets"
STAGE_ROOT = BASE / "current"   # dossier de travail : tout est téléchargé ici d'abord
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".ico")
CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")

# nom du logo (assets/<nom>.png) -> domaines reconnus.
# Dépose simplement un <nom>.png dans assets pour qu'il apparaisse dans l'app.
PLATFORMS = {
    "tiktok": ("tiktok.com",),
    "spotify": ("spotify.com",),
    "youtube": ("youtube.com", "youtu.be"),
    "soundcloud": ("soundcloud.com",),
    "instagram": ("instagram.com",),
    "twitter": ("twitter.com", "x.com"),
    "twitch": ("twitch.tv",),
    "facebook": ("facebook.com", "fb.watch"),
    "reddit": ("reddit.com",),
    "vimeo": ("vimeo.com",),
    "dailymotion": ("dailymotion.com",),
    "bandcamp": ("bandcamp.com",),
}


# ───────────────────────── utilitaires ─────────────────────────

def find_asset(stem):
    """Cherche assets/<stem>.<png|jpg|jpeg|webp|ico>, sans tenir compte de la casse."""
    if not ASSETS.is_dir():
        return None
    for p in ASSETS.iterdir():
        if p.is_file() and p.stem.lower() == stem.lower() and p.suffix.lower() in IMG_EXT:
            return p
    return None


def looks_like_url(text):
    t = text.strip().lower()
    return (t.startswith(("http://", "https://")) and "." in t) or t.startswith("spotify:")


def _host(text):
    return urlparse(text.strip().lower()).netloc.split(":")[0]


def detect_platform(text):
    """Retourne le nom de la plateforme, 'other' pour un autre site, None si ce n'est pas un lien."""
    t = text.strip().lower()
    if not looks_like_url(t):
        return None
    if t.startswith("spotify:"):
        return "spotify"
    host = _host(t)
    for name, domains in PLATFORMS.items():
        if any(host == d or host.endswith("." + d) for d in domains):
            return name
    return "other"


def is_spotify(url):
    return detect_platform(url) == "spotify"


def safe_name(name):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name or "Sans titre"


def mo(n):
    return f"{n / 1_048_576:.1f} Mo"


def ffmpeg_ok():
    return shutil.which("ffmpeg") is not None


def clean_error(e):
    msg = _ANSI.sub("", str(e)).strip()
    msg = msg.splitlines()[-1] if msg else "Erreur inconnue"
    msg = re.sub(r"^ERROR:\s*", "", msg)[:220]
    if re.search(r"HTTP Error 4\d\d|Unable to extract|Sign in|confirm you", msg, re.I):
        msg += "  (essaie : pip install -U yt-dlp)"
    return msg


def _tail(text):
    lines = [_ANSI.sub("", ln).strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln and ln[0] not in "│╭╰─┃┏┗"]
    return lines[-1][:220] if lines else ""


def _env():
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["NO_COLOR"] = "1"
    return env


_RUN = dict(capture_output=True, text=True, encoding="utf-8", errors="replace",
            creationflags=CREATE_NO_WINDOW)


# ───────────────────────── types ─────────────────────────

@dataclass
class MediaInfo:
    url: str
    source: str              # "spotify" ou "web"
    kind: str                # "track", "video", "album", "playlist"
    title: str               # texte affiché dans les logs
    is_collection: bool = False
    collection_name: str = ""
    count: int = 1


class Cancelled(Exception):
    pass


class Cancel:
    """Jeton d'annulation partagé entre l'interface et le téléchargement."""

    def __init__(self):
        self._ev = threading.Event()
        self.proc = None
        self.discard = False    # True : supprimer le dossier de travail à la fin

    def is_set(self):
        return self._ev.is_set()

    def set(self):
        self._ev.set()
        p = self.proc
        if p is not None and p.poll() is None:
            try:
                if sys.platform == "win32":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
                                   capture_output=True, creationflags=CREATE_NO_WINDOW)
                else:
                    p.terminate()
            except Exception:
                pass


# ───────────────────────── recherche du titre ─────────────────────────

def analyse(url):
    url = url.strip()
    if is_spotify(url):
        return _analyse_spotify(url)
    return _analyse_web(url)


def _single(url):
    """Vrai si le lien pointe vers UNE vidéo (même s'il contient &list=...)."""
    u = url.lower()
    return ("youtube.com/watch" in u and "v=" in u) or "youtu.be/" in u or "youtube.com/shorts/" in u


def _analyse_spotify(url):
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "meta.spotdl"
        r = subprocess.run(
            [sys.executable, "-m", "spotdl", "save", url, "--save-file", str(out)],
            env=_env(), **_RUN)
        if r.returncode != 0 or not out.exists():
            raise RuntimeError(_tail((r.stdout or "") + "\n" + (r.stderr or ""))
                               or "spotdl n'a pas pu lire ce lien.")
        songs = json.loads(out.read_text(encoding="utf-8"))
    if not songs:
        raise RuntimeError("Aucun titre trouvé sur ce lien Spotify.")

    low = url.lower()
    kind = ("album" if ("/album/" in low or ":album:" in low)
            else "playlist" if ("/playlist/" in low or ":playlist:" in low)
            else "track")
    first = songs[0]
    if kind == "track" and len(songs) > 1:      # lien artiste, etc.
        kind = "playlist"
    if kind == "track":
        artist = first.get("artist") or ", ".join(first.get("artists") or [])
        title = f"{artist} - {first.get('name', '?')}".strip(" -")
        return MediaInfo(url, "spotify", "track", title)
    if kind == "album":
        name = first.get("album_name") or "Album"
    else:
        name = first.get("list_name") or first.get("artist") or "Playlist"
    return MediaInfo(url, "spotify", kind, f"{name} ({len(songs)} titres)", True, name, len(songs))


def _analyse_web(url):
    import yt_dlp

    opts = {
        "quiet": True, "no_warnings": True, "skip_download": True,
        "extract_flat": "in_playlist", "noplaylist": _single(url),
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            data = ydl.extract_info(url, download=False)
    except yt_dlp.utils.DownloadError as e:
        raise RuntimeError(clean_error(e))
    if not data:
        raise RuntimeError("Aucune information trouvée pour ce lien.")

    if data.get("_type") == "playlist" or data.get("entries") is not None:
        entries = [e for e in (data.get("entries") or []) if e]
        name = data.get("title") or "Playlist"
        n = len(entries) or data.get("playlist_count") or 0
        return MediaInfo(url, "web", "playlist", f"{name} ({n} vidéos)", True, name, max(n, 1))
    title = data.get("title") or data.get("description") or data.get("id") or "Sans titre"
    return MediaInfo(url, "web", "video", title.strip().splitlines()[0][:120])


# ───────────────────────── téléchargement ─────────────────────────

def download(info, fmt, meta, stage, on_progress, cancel):
    """
    Télécharge `info` dans le dossier de travail `stage` (sous « current »).
    on_progress(fraction | None, texte) est appelé régulièrement.
    Retourne la liste des fichiers téléchargés.
    """
    stage = Path(stage)
    stage.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    try:
        if info.source == "spotify":
            _download_spotify(info, stage, on_progress, cancel, t0)
        else:
            _download_web(info, fmt, meta, stage, on_progress, cancel)
        if cancel.is_set():
            raise Cancelled()
    except Cancelled:
        _cleanup_partials(stage, t0)
        raise

    files = _new_media(stage, t0)
    if not files:
        raise RuntimeError("Aucun fichier n'a été téléchargé.")
    if not meta:
        on_progress(None, "Suppression des métadonnées...")
        strip_metadata(files)
    return files


def remove_dir(path):
    if path:
        shutil.rmtree(path, ignore_errors=True)


def clear_stage_root():
    """Vide « current » (restes d'une session précédente)."""
    STAGE_ROOT.mkdir(parents=True, exist_ok=True)
    for p in STAGE_ROOT.iterdir():
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
        else:
            try:
                p.unlink()
            except OSError:
                pass


def _unique(path):
    """Évite d'écraser un fichier existant : nom.mp3 -> nom (1).mp3"""
    if not path.exists():
        return path
    i = 1
    while True:
        cand = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not cand.exists():
            return cand
        i += 1


def move_files(files, dest, info):
    """
    Déplace les fichiers téléchargés vers le dossier choisi.
    Un album / une playlist va dans un sous-dossier à son nom.
    Retourne (fichiers déplacés, dossier final).
    """
    dest = Path(dest)
    if info.is_collection:
        dest = dest / safe_name(info.collection_name)
    dest.mkdir(parents=True, exist_ok=True)
    moved = []
    for f in files:
        target = _unique(dest / f.name)
        shutil.move(str(f), str(target))
        moved.append(target)
    return moved, dest


def _new_media(dest, t0):
    out = []
    for p in dest.iterdir():
        try:
            if p.is_file() and p.suffix.lower() in (".mp3", ".mp4") and p.stat().st_mtime >= t0 - 1:
                out.append(p)
        except OSError:
            pass
    return sorted(out)


def _cleanup_partials(dest, t0):
    bad = {".part", ".temp", ".ytdl", ".tmp", ".webp", ".jpg", ".jpeg", ".png"}
    for p in dest.iterdir():
        try:
            if p.is_file() and p.suffix.lower() in bad and p.stat().st_mtime >= t0 - 1:
                p.unlink()
        except OSError:
            pass


def strip_metadata(files):
    """Retire titre, artiste, pochette... sans ré-encoder."""
    for f in files:
        tmp = f.with_name(f.stem + ".strip" + f.suffix)
        streams = "0:a" if f.suffix.lower() == ".mp3" else "0"
        r = subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", str(f), "-map", streams,
             "-map_metadata", "-1", "-map_chapters", "-1", "-fflags", "+bitexact",
             "-c", "copy", str(tmp)],
            capture_output=True, creationflags=CREATE_NO_WINDOW)
        if r.returncode == 0 and tmp.exists():
            tmp.replace(f)
        else:
            tmp.unlink(missing_ok=True)


def _download_web(info, fmt, meta, dest, on_progress, cancel):
    import yt_dlp
    from yt_dlp.utils import DownloadCancelled, DownloadError

    def hook(d):
        if cancel.is_set():
            raise DownloadCancelled()
        if d.get("status") == "downloading":
            done = d.get("downloaded_bytes") or 0
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            ii = d.get("info_dict") or {}
            pre = ""
            if info.is_collection and ii.get("playlist_index"):
                pre = f"[{ii['playlist_index']}/{ii.get('n_entries') or info.count}] "
            if total:
                on_progress(done / total, f"{pre}{mo(done)} / {mo(total)}")
            else:
                on_progress(None, f"{pre}{mo(done)}")

    def pp_hook(d):
        if d.get("status") == "started":
            on_progress(None, "Conversion / finalisation...")

    opts = {
        "outtmpl": str(dest / "%(title)s.%(ext)s"),
        "quiet": True, "no_warnings": True, "noprogress": True,
        "noplaylist": _single(info.url),
        "ignoreerrors": info.is_collection,
        "progress_hooks": [hook],
        "postprocessor_hooks": [pp_hook],
        "windowsfilenames": True,
        "trim_file_names": 150,
        "retries": 5,
        "postprocessors": [],
    }
    if fmt == "mp3":
        opts["format"] = "bestaudio/best"
        opts["postprocessors"].append(
            {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"})
    else:
        opts["format"] = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"
        opts["merge_output_format"] = "mp4"

    if meta:
        opts["writethumbnail"] = True
        opts["postprocessors"] += [
            {"key": "FFmpegThumbnailsConvertor", "format": "jpg", "when": "before_dl"},
            {"key": "FFmpegMetadata", "add_metadata": True},
            {"key": "EmbedThumbnail"},
        ]

    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([info.url])
    except DownloadCancelled:
        raise Cancelled()
    except DownloadError as e:
        if cancel.is_set():
            raise Cancelled()
        raise RuntimeError(clean_error(e))


def _scan(dest, t0):
    size = done = 0
    for p in dest.iterdir():
        try:
            st = p.stat()
            if not p.is_file() or st.st_mtime < t0 - 1:
                continue
        except OSError:
            continue
        size += st.st_size
        if p.suffix.lower() == ".mp3":
            done += 1
    return size, done


def _download_spotify(info, dest, on_progress, cancel, t0):
    # Spotify est protégé (DRM) : spotdl lit la track/l'album sur Spotify,
    # puis récupère l'audio correspondant sur YouTube Music.
    cmd = [sys.executable, "-m", "spotdl", "download", info.url,
           "--output", str(dest / "{artists} - {title}.{output-ext}"),
           "--format", "mp3"]
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        encoding="utf-8", errors="replace", creationflags=CREATE_NO_WINDOW, env=_env())
    cancel.proc = proc

    tail = deque(maxlen=60)

    def reader():
        for line in proc.stdout:
            tail.append(line)

    th = threading.Thread(target=reader, daemon=True)
    th.start()

    on_progress(None, "Recherche de l'audio (YouTube Music)...")
    while proc.poll() is None:
        if cancel.is_set():
            break
        size, done = _scan(dest, t0)
        if info.is_collection:
            frac = min(done / max(info.count, 1), 0.99)
            on_progress(frac, f"{done}/{info.count} titres  -  {mo(size)}")
        elif size:
            on_progress(None, mo(size))
        time.sleep(0.4)

    if cancel.is_set():
        try:
            proc.wait(timeout=5)
        except Exception:
            pass
        raise Cancelled()

    th.join(timeout=2)
    if proc.returncode != 0:
        raise RuntimeError(_tail("".join(tail)) or "spotdl a échoué.")
    on_progress(1.0, "Terminé")
