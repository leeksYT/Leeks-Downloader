"""gui.py - interface de Leeks Downloader (Tkinter + Pillow)."""
import json
import queue
import threading
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter import filedialog, messagebox

from PIL import Image, ImageDraw, ImageFilter, ImageOps, ImageStat, ImageTk

import core

APP_NAME = "Leeks Downloader"
W, H = 900, 664
FONT = "Segoe UI"
ACCENT = "#7C5CFF"
GREEN = "#16A34A"
RED = "#E5484D"
GREY = "#6B6B7B"
LOG_BG = "#12121A"
CONFIG = core.BASE / "config.json"
LOGO_SIZE = 40
BAR_W = 520
MAX_JOBS = 8

ACTIVE = ("searching", "staging", "moving")     # un travail est en cours
CHIP_COLOR = {"searching": ACCENT, "staging": ACCENT, "moving": ACCENT,
              "ready": GREEN, "error": RED, "done": GREY, "stopped": GREY}

# géométrie de la ligne du lien
ENTRY_X, ENTRY_Y, ENTRY_H = 80, 178, 44
FULL_W, SHORT_W = 740, 464


# ───────────────────────── images ─────────────────────────

def load_img(stem, box=None):
    p = core.find_asset(stem)
    if not p:
        return None
    try:
        im = Image.open(p).convert("RGBA")
    except Exception:
        return None
    if box:
        im.thumbnail(box, Image.LANCZOS)
    return im


def dim(im, k):
    im = im.copy()
    im.putalpha(im.getchannel("A").point(lambda v: int(v * k)))
    return im


def is_light(im):
    try:
        gray = ImageOps.grayscale(im.convert("RGB"))
        return ImageStat.Stat(gray, mask=im.getchannel("A")).mean[0] > 140
    except Exception:
        return False


def rounded_mask(w, h, r, s=4):
    m = Image.new("L", (w * s, h * s), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w * s - 1, h * s - 1), radius=r * s, fill=255)
    return m.resize((w, h), Image.LANCZOS)


# ───────────────────────── widgets maison ─────────────────────────

class ProgressBar:
    """Barre de progression dessinée sur un Canvas (intégrée dans les logs)."""

    def __init__(self, parent, width=BAR_W, height=22):
        self.w, self.h = width, height
        self.c = tk.Canvas(parent, width=width, height=height, bg="#2A2A36",
                           highlightthickness=0, bd=0)
        self.fill = self.c.create_rectangle(0, 0, 0, height, fill=ACCENT, width=0)
        self.lbl = self.c.create_text(width / 2, height / 2, text="", fill="#FFFFFF",
                                      font=(FONT, 9, "bold"))
        self.frac = 0.0
        self.indet = False
        self.alive = True
        self._pos = 0

    def set(self, frac, text=""):
        if not self.alive:
            return
        self.c.itemconfigure(self.lbl, text=text)
        if frac is None:
            if not self.indet:
                self.indet = True
                self._tick()
        else:
            self.indet = False
            self.frac = max(0.0, min(1.0, frac))
            self.c.coords(self.fill, 0, 0, self.w * self.frac, self.h)

    def _tick(self):
        if not (self.alive and self.indet):
            return
        seg = self.w * 0.25
        self._pos = (self._pos + 10) % (self.w + seg)
        self.c.coords(self.fill, self._pos - seg, 0, self._pos, self.h)
        self.c.after(30, self._tick)

    def destroy(self):
        self.alive = False
        self.indet = False
        try:
            self.c.destroy()
        except tk.TclError:
            pass


class Btn:
    """Bouton arrondi dessiné sur le canvas : normal / survol / sélectionné / grisé."""

    def __init__(self, app, x, y, w, h, text, command, kind="toggle", icon=None, size=12, dark=False):
        self.app, self.x, self.y, self.w, self.h = app, x, y, w, h
        self.text, self.command, self.kind, self.size, self.dark = text, command, kind, size, dark
        self.icon = icon
        self.enabled = True
        self.selected = False   # MP3 / MP4 choisi
        self.green = False      # Metadatas activé
        self.hover = False
        self.visible = True
        c = app.c
        self.bg_id = c.create_image(x, y, anchor="nw")
        self.icon_id = c.create_image(0, 0, anchor="w", image=icon) if icon else None
        self.txt_id = c.create_text(0, 0, text=text, anchor="w" if (icon and text) else "center")
        self.ids = [i for i in (self.bg_id, self.icon_id, self.txt_id) if i]
        for i in self.ids:
            c.tag_bind(i, "<Button-1>", self._click)
            c.tag_bind(i, "<Enter>", self._enter)
            c.tag_bind(i, "<Leave>", self._leave)
        self.render()

    def render(self):
        outline, border, bold, italic = None, 0, False, False
        if not self.enabled:
            fill, fg = "#8E8E9A", "#D9D9E0"
            italic = self.kind == "toggle"
        elif self.kind == "primary":
            fill, fg, bold = ("#8E72FF" if self.hover else ACCENT), "#FFFFFF", True
        elif self.kind == "secondary":
            if self.dark:
                fill, fg = ("#3C3C4E" if self.hover else "#2B2B38"), "#FFFFFF"
            else:
                fill, fg = ("#FFFFFF" if self.hover else "#ECECF2"), "#111111"
        else:  # toggle : MP3 / MP4 / Metadatas
            fill = "#FFFFFF" if (self.hover or self.selected) else "#ECECF2"
            fg = "#111111"
            if self.green:
                outline, border, fg, bold = GREEN, 3, GREEN, True
            elif self.selected:
                outline, border, bold = ACCENT, 3, True

        c = self.app.c
        c.itemconfigure(self.bg_id, image=self.app.pill(self.w, self.h, fill, outline, border))
        f = self.app.font(bold, italic, self.size)
        c.itemconfigure(self.txt_id, font=f, fill=fg)
        cy = self.y + self.h / 2
        if self.icon_id:
            iw = self.icon.width()
            if self.text:
                sx = self.x + (self.w - (iw + 8 + f.measure(self.text))) / 2
                c.coords(self.icon_id, sx, cy)
                c.coords(self.txt_id, sx + iw + 8, cy)
            else:
                c.coords(self.icon_id, self.x + (self.w - iw) / 2, cy)
        else:
            c.coords(self.txt_id, self.x + self.w / 2, cy)

    def set_visible(self, v):
        self.visible = v
        if not v:
            self.hover = False
            self.app.c.config(cursor="")
        for i in self.ids:
            self.app.c.itemconfigure(i, state="normal" if v else "hidden")

    def _click(self, _e):
        if self.enabled and self.visible and self.command:
            self.command()

    def _enter(self, _e):
        self.hover = True
        self.app.c.config(cursor="hand2" if self.enabled else "")
        self.render()

    def _leave(self, _e):
        self.hover = False
        self.app.c.config(cursor="")
        self.render()


class Job:
    """Une recherche (et son téléchargement). On peut en avoir plusieurs en même temps."""

    def __init__(self, jid, fmt="mp3", meta_pref=False):
        self.id = jid
        self.url = ""
        # new / searching / staging / ready / moving / done / error / stopped
        self.state = "new"
        self.fmt = fmt
        self.meta_pref = meta_pref      # réglage du bouton Metadatas
        self.meta = False               # réglage réellement utilisé pour ce téléchargement
        self.info = None
        self.files = []
        self.stage = None               # dossier de travail dans « current »
        self.cancel = None              # jeton d'annulation de la tentative en cours
        self.entries = []               # contenu des logs : ("line", texte, tag) ou ("bar",)
        self.bar_state = (0.0, "")


# ───────────────────────── application ─────────────────────────

class App:
    KINDS = {"track": "Titre trouvé", "video": "Vidéo trouvée",
             "album": "Album trouvé", "playlist": "Playlist trouvée"}

    def __init__(self):
        self.root = tk.Tk()
        self.root.title(APP_NAME)
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.geometry(f"{W}x{H}+{(sw - W) // 2}+{max((sh - H) // 2 - 20, 0)}")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.q = queue.Queue()
        self.cfg = self._load_cfg()
        self.jobs, self.by_id = [], {}
        self.next_id, self.seq = 1, 0
        self.bar = None
        self._loading = False
        self._fonts, self._pills, self._keep = {}, {}, []
        self.logos = {}

        core.clear_stage_root()
        self.sel = self.make_job()

        self._set_icon()
        self._build()
        self.select(self.sel)
        self.root.after(60, self.poll)
        self.entry.focus_set()

    # ---------- outils ----------

    def _load_cfg(self):
        try:
            return json.loads(CONFIG.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_cfg(self):
        try:
            CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass

    def font(self, bold=False, italic=False, size=12):
        key = (bold, italic, size)
        if key not in self._fonts:
            self._fonts[key] = tkfont.Font(
                root=self.root, family=FONT, size=size,
                weight="bold" if bold else "normal", slant="italic" if italic else "roman")
        return self._fonts[key]

    def pill(self, w, h, fill, outline=None, border=0, radius=14):
        key = (w, h, fill, outline, border, radius)
        if key not in self._pills:
            s = 4
            im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rounded_rectangle((0, 0, w * s - 1, h * s - 1), radius=radius * s,
                                fill=outline if (outline and border) else fill)
            if outline and border:
                b = border * s
                d.rounded_rectangle((b, b, w * s - 1 - b, h * s - 1 - b),
                                    radius=max(radius - border, 1) * s, fill=fill)
            self._pills[key] = ImageTk.PhotoImage(im.resize((w, h), Image.LANCZOS))
        return self._pills[key]

    def glass(self, x, y, w, h, radius=22, darkness=0.55):
        """Panneau « verre dépoli » : le fond, flouté et assombri."""
        region = self.bg.crop((x, y, x + w, y + h)).filter(ImageFilter.GaussianBlur(6))
        region = Image.blend(region, Image.new("RGB", (w, h), (10, 10, 18)), darkness)
        out = region.convert("RGBA")
        out.putalpha(rounded_mask(w, h, radius))
        ph = ImageTk.PhotoImage(out)
        self._keep.append(ph)
        self.c.create_image(x, y, image=ph, anchor="nw")

    def shadow_text(self, x, y, text, size, anchor="center"):
        f = (FONT, size, "bold")
        self.c.create_text(x + 1, y + 1, text=text, font=f, fill="#000000", anchor=anchor)
        self.c.create_text(x, y, text=text, font=f, fill="#FFFFFF", anchor=anchor)

    def _set_icon(self):
        im = load_img("icon")
        if not im:
            return
        try:
            icons = [ImageTk.PhotoImage(ImageOps.pad(im, (s, s), color=(0, 0, 0, 0)))
                     for s in (16, 32, 48)]
            self._keep += icons
            self.root.iconphoto(True, *icons)
        except Exception:
            pass

    # ---------- construction ----------

    def _build(self):
        c = self.c = tk.Canvas(self.root, width=W, height=H, highlightthickness=0, bd=0)
        c.pack()

        # fond
        bg = load_img("background")
        if bg:
            self.bg = ImageOps.fit(bg.convert("RGB"), (W, H), Image.LANCZOS)
        else:
            grad = Image.linear_gradient("L").resize((W, H))
            self.bg = ImageOps.colorize(grad, black="#2A1750", white="#0A1024")
        self.bg_tk = ImageTk.PhotoImage(self.bg)
        c.create_image(0, 0, image=self.bg_tk, anchor="nw")

        # titre
        t = load_img("title", (620, 70))
        if t:
            self.title_tk = ImageTk.PhotoImage(t)
            c.create_image(W // 2, 10, image=self.title_tk, anchor="n")
        else:
            self.shadow_text(W // 2, 46, APP_NAME, 30)

        # logos des plateformes (tous les <nom>.png trouvés dans assets)
        found = []
        for name in core.PLATFORMS:
            im = load_img(name, (LOGO_SIZE, LOGO_SIZE))
            if im:
                found.append((name, im))
        gap = 20
        x = (W - (sum(im.width for _, im in found) + gap * max(len(found) - 1, 0))) / 2
        for name, im in found:
            normal, faded = ImageTk.PhotoImage(im), ImageTk.PhotoImage(dim(im, 0.3))
            item = c.create_image(x, 106, image=normal, anchor="w")
            self.logos[name] = (item, normal, faded)
            x += im.width + gap

        # carte principale
        self.glass(50, 138, 800, 226)
        self.shadow_text(W // 2, 160, "Coller le lien du fichier à télécharger", 13)

        # 1) le lien
        self.var = tk.StringVar()
        self.entry = tk.Entry(
            c, textvariable=self.var, font=(FONT, 12), bd=0, relief="flat",
            bg="#FFFFFF", fg="#111111", insertbackground="#111111",
            highlightthickness=2, highlightbackground="#D6D6E0", highlightcolor=ACCENT,
            disabledbackground="#E4E4EC", disabledforeground="#55555F")
        self.entry_win = c.create_window(ENTRY_X, ENTRY_Y, window=self.entry, anchor="nw",
                                         width=FULL_W, height=ENTRY_H)
        self.entry.bind("<Return>", lambda e: self.on_search())

        # à droite du lien : Arrêter (croix) + Relancer une recherche
        cross = load_img("croix", (18, 18))
        cross_tk = None
        if cross:
            cross_tk = ImageTk.PhotoImage(cross)
            self._keep.append(cross_tk)
        self.b_stop = Btn(self, 556, ENTRY_Y, 44, ENTRY_H, "" if cross_tk else "✕", self.on_stop,
                          kind="secondary", icon=cross_tk, size=13, dark=True)
        back = load_img("return", (20, 20))
        back_tk = None
        if back:
            back_tk = ImageTk.PhotoImage(back)
            self._keep.append(back_tk)
        self.b_back = Btn(self, 612, ENTRY_Y, 208, ENTRY_H, "Relancer une recherche", self.on_new,
                          kind="secondary", icon=back_tk, size=11,
                          dark=bool(back) and is_light(back))
        self.b_stop.set_visible(False)
        self.b_back.set_visible(False)

        # format
        bx = (W - 490) // 2
        self.b_mp3 = Btn(self, bx, 238, 150, 44, "MP3", lambda: self.pick_fmt("mp3"))
        self.b_mp4 = Btn(self, bx + 170, 238, 150, 44, "MP4", lambda: self.pick_fmt("mp4"))
        self.b_meta = Btn(self, bx + 340, 238, 150, 44, "Metadatas", self.toggle_meta)

        # 2) Rechercher   3) Télécharger
        self.b_search = Btn(self, 190, 298, 250, 50, "Rechercher", self.on_search,
                            kind="secondary", size=13)
        self.b_dl = Btn(self, 460, 298, 250, 50, "Télécharger", self.on_download,
                        kind="primary", size=13)

        # logs : le carré noir contient le titre « Logs », les pastilles et le texte
        self.panel = self.pill(800, 246, LOG_BG, radius=18)
        c.create_image(50, 378, image=self.panel, anchor="nw")
        c.create_text(72, 393, text="Logs", anchor="w", fill="#C9C9D6", font=(FONT, 11, "bold"))
        self.log = tk.Text(c, font=("Consolas", 10), bg=LOG_BG, fg="#E8E8F0", bd=0,
                           highlightthickness=0, wrap="word", padx=10, pady=6,
                           state="disabled", cursor="arrow", spacing1=2)
        for tag, color in (("info", "#E8E8F0"), ("dim", "#9A9AAA"),
                           ("ok", "#4ADE80"), ("err", "#FF6B6B")):
            self.log.tag_configure(tag, foreground=color)
        c.create_window(60, 410, window=self.log, anchor="nw", width=780, height=204)

        # pied de page
        c.create_text(W // 2, 644, text=f"{APP_NAME} - 2026", fill="#C9C9D6", font=(FONT, 9))

        self.var.trace_add("write", self.on_entry_change)

    # ---------- recherches (jobs) ----------

    def make_job(self, like=None):
        j = Job(self.next_id, like.fmt if like else "mp3", like.meta_pref if like else False)
        self.next_id += 1
        self.jobs.append(j)
        self.by_id[j.id] = j
        return j

    def select(self, j):
        self.sel = j
        self._loading = True
        self.var.set(j.url)
        self._loading = False
        self.render_log()
        self.refresh()

    def reset_job(self, j, note=None):
        """Repart de zéro : supprime le résultat (et les fichiers de « current »)."""
        if j.cancel:
            j.cancel.discard = True
        core.remove_dir(j.stage)
        j.state = "new"
        j.info = None
        j.files = []
        j.entries = []
        j.bar_state = (0.0, "")
        if note:
            j.entries.append(("line", note, "dim"))
        if j is self.sel:
            self.render_log()

    def close_job(self, j):
        idx = self.jobs.index(j)
        if j.cancel:
            j.cancel.discard = True
            j.cancel.set()
        core.remove_dir(j.stage)
        self.jobs.remove(j)
        self.by_id.pop(j.id, None)
        if j is self.sel:
            if not self.jobs:
                self.make_job()
            self.select(self.jobs[min(idx, len(self.jobs) - 1)])
        else:
            self.refresh()

    # ---------- logs ----------

    def add_line(self, j, text, tag="info"):
        j.entries.append(("line", text, tag))
        if j is self.sel:
            self.log.config(state="normal")
            self.log.insert("end", text + "\n", tag)
            self.log.config(state="disabled")
            self.log.see("end")

    def _embed_bar(self, j):
        self.log.config(state="normal")
        self.bar = ProgressBar(self.log)
        self.bar.set(*j.bar_state)
        self.log.window_create("end", window=self.bar.c)
        self.log.insert("end", "\n")
        self.log.config(state="disabled")
        self.log.see("end")

    def add_bar(self, j):
        j.entries.append(("bar",))
        j.bar_state = (None, "Démarrage...")
        if j is self.sel:
            self._embed_bar(j)

    def set_bar(self, j, frac, text):
        j.bar_state = (frac, text)
        if j is self.sel and self.bar:
            self.bar.set(frac, text)

    def render_log(self):
        """Réaffiche les logs de la recherche sélectionnée."""
        if self.bar:
            self.bar.destroy()
            self.bar = None
        self.log.config(state="normal")
        self.log.delete("1.0", "end")
        self.log.config(state="disabled")
        for e in self.sel.entries:
            if e[0] == "line":
                self.log.config(state="normal")
                self.log.insert("end", e[1] + "\n", e[2])
                self.log.config(state="disabled")
            else:
                self._embed_bar(self.sel)
        self.log.see("end")

    # ---------- affichage selon l'état ----------

    def set_platform(self, name):
        for key, (item, normal, faded) in self.logos.items():
            self.c.itemconfigure(item, image=normal if (name is None or key == name) else faded)

    def draw_chips(self):
        """Une pastille par recherche, en haut à droite du carré noir."""
        self.c.delete("chip")
        self.c.config(cursor="")
        x = 836
        for j in reversed(self.jobs):
            w = 34 if j.id < 10 else 42
            x -= w
            selected = j is self.sel
            color = CHIP_COLOR.get(j.state)
            img = self.pill(w, 24, "#FFFFFF" if selected else "#2A2A36",
                            color, 2 if color else 0, radius=8)
            a = self.c.create_image(x, 381, image=img, anchor="nw", tags=("chip",))
            b = self.c.create_text(x + w / 2, 393, text=str(j.id), tags=("chip",),
                                   fill="#111111" if selected else "#FFFFFF",
                                   font=(FONT, 9, "bold"))
            for item in (a, b):
                self.c.tag_bind(item, "<Button-1>", lambda e, jj=j: self.select(jj))
                self.c.tag_bind(item, "<Enter>", lambda e: self.c.config(cursor="hand2"))
                self.c.tag_bind(item, "<Leave>", lambda e: self.c.config(cursor=""))
            x -= 6

    def refresh(self):
        j = self.sel
        active = j.state in ACTIVE
        spotify = core.is_spotify(j.url)
        if spotify:
            j.fmt = "mp3"           # Spotify = audio uniquement

        self.b_mp3.selected = j.fmt == "mp3"
        self.b_mp4.selected = j.fmt == "mp4"
        self.b_mp4.enabled = not spotify
        # Metadatas : noir en MP3, vert quand activé, grisé + italique en MP4
        self.b_meta.enabled = j.fmt == "mp3"
        self.b_meta.green = j.meta_pref and j.fmt == "mp3"
        self.b_search.enabled = (j.state in ("new", "error", "stopped", "done")
                                 and core.looks_like_url(j.url))
        self.b_dl.enabled = j.state == "ready"
        for b in (self.b_mp3, self.b_mp4, self.b_meta, self.b_search, self.b_dl):
            b.render()

        # une fois la recherche lancée : champ raccourci + Arrêter + Relancer une recherche
        has_job = j.state != "new"
        self.b_back.set_visible(has_job)
        self.b_stop.set_visible(has_job and j.state != "moving")
        self.entry.config(state="disabled" if active else "normal")
        self.c.itemconfigure(self.entry_win, width=SHORT_W if has_job else FULL_W)
        self.set_platform(core.detect_platform(j.url))
        self.draw_chips()

    # ---------- actions ----------

    def pick_fmt(self, fmt):
        j = self.sel
        if j.state in ACTIVE or j.fmt == fmt:
            return
        j.fmt = fmt
        if j.state != "new":
            self.reset_job(j, "Réglages modifiés : clique sur Rechercher.")
        self.refresh()

    def toggle_meta(self):
        j = self.sel
        if j.state in ACTIVE or j.fmt != "mp3":
            return
        j.meta_pref = not j.meta_pref
        if j.state != "new":
            self.reset_job(j, "Réglages modifiés : clique sur Rechercher.")
        self.refresh()

    def on_entry_change(self, *_):
        if self._loading:
            return
        j = self.sel
        if j.state in ACTIVE:
            return
        j.url = self.var.get().strip()
        if j.state != "new":
            self.reset_job(j)
        self.refresh()

    def on_search(self):
        """Rechercher : trouve le titre puis télécharge tout dans « current »."""
        j = self.sel
        if j.state not in ("new", "error", "stopped", "done"):
            return
        url = self.var.get().strip()
        if not core.looks_like_url(url):
            self.add_line(j, "Colle d'abord un lien (https://...).", "err")
            return
        self.reset_job(j)
        j.url = url
        if core.is_spotify(url):
            j.fmt = "mp3"
        j.meta = j.meta_pref and j.fmt == "mp3"
        self.seq += 1
        j.stage = core.STAGE_ROOT / f"{j.id}-{self.seq}"
        j.cancel = core.Cancel()
        j.state = "searching"
        self.add_line(j, "Recherche du titre...")
        self.refresh()
        threading.Thread(target=self._worker, daemon=True,
                         args=(j.id, url, j.fmt, j.meta, j.stage, j.cancel)).start()

    def _worker(self, jid, url, fmt, meta, stage, cancel):
        try:
            info = core.analyse(url)
            self.q.put(("found", jid, cancel, info))
            if cancel.is_set():
                raise core.Cancelled()
            files = core.download(
                info, fmt, meta, stage,
                lambda frac, text: self.q.put(("progress", jid, cancel, frac, text)), cancel)
            self.q.put(("staged", jid, cancel, files))
        except core.Cancelled:
            pass
        except Exception as e:
            self.q.put(("error", jid, cancel, core.clean_error(e)))
        finally:
            if cancel.discard:
                core.remove_dir(stage)

    def on_download(self):
        """Télécharger : choisit le dossier puis déplace les fichiers déjà prêts."""
        j = self.sel
        if j.state != "ready" or not j.files:
            return
        start = self.cfg.get("last_dir") or str(Path.home() / "Music")
        if not Path(start).exists():
            start = str(Path.home())
        folder = filedialog.askdirectory(parent=self.root, initialdir=start,
                                         title="Choisir le dossier de destination")
        if not folder:
            return
        dest = Path(folder)
        self.cfg["last_dir"] = str(dest)
        self._save_cfg()

        j.state = "moving"
        self.set_bar(j, None, "Déplacement des fichiers...")
        self.refresh()
        threading.Thread(target=self._move_worker, daemon=True,
                         args=(j.id, j.cancel, list(j.files), dest, j.info, j.stage)).start()

    def _move_worker(self, jid, tok, files, dest, info, stage):
        try:
            moved, target = core.move_files(files, dest, info)
            core.remove_dir(stage)
            self.q.put(("moved", jid, tok, moved, target))
        except Exception as e:
            self.q.put(("move_error", jid, tok, core.clean_error(e)))

    def on_new(self):
        """Relancer une recherche : en démarre une autre, sans toucher à celles en cours."""
        if len(self.jobs) >= MAX_JOBS:
            old = next((x for x in self.jobs if x.state in ("done", "stopped", "error")), None)
            if old is None:
                self.add_line(self.sel, f"Maximum {MAX_JOBS} recherches en même temps.", "err")
                return
            self.close_job(old)
        self.select(self.make_job(like=self.sel))
        self.entry.focus_set()

    def on_stop(self):
        """Croix : arrête la recherche / le téléchargement en cours, ou ferme une recherche terminée."""
        j = self.sel
        if j.state in ("searching", "staging"):
            j.cancel.discard = True
            j.cancel.set()
            j.state = "stopped"
            self.set_bar(j, j.bar_state[0] or 0.0, "Arrêté")
            self.add_line(j, "Arrêté.", "dim")
            self.refresh()
        elif j.state in ("ready", "done", "error", "stopped"):
            self.close_job(j)

    def on_close(self):
        pending = [j for j in self.jobs if j.state in ("searching", "staging", "ready", "moving")]
        if pending and not messagebox.askyesno(
                APP_NAME,
                f"{len(pending)} recherche(s) en cours ou pas encore enregistrée(s).\n"
                "Quitter quand même ? Les fichiers de « current » seront supprimés."):
            return
        for j in self.jobs:
            if j.cancel:
                j.cancel.discard = True
                j.cancel.set()
        core.clear_stage_root()
        self.root.destroy()

    # ---------- messages venant des threads ----------

    def poll(self):
        try:
            while True:
                self.handle(self.q.get_nowait())
        except queue.Empty:
            pass
        finally:
            self.root.after(60, self.poll)

    def handle(self, m):
        kind, jid, tok = m[0], m[1], m[2]
        j = self.by_id.get(jid)
        if j is None or j.cancel is not tok:      # recherche fermée ou relancée depuis
            return

        if kind == "progress":
            if j.state == "staging":
                self.set_bar(j, m[3], m[4])
            return

        if kind == "found":
            if j.state != "searching":
                return
            j.info = m[3]
            j.state = "staging"
            self.add_line(j, f"{self.KINDS.get(j.info.kind, 'Trouvé')} : {j.info.title}", "ok")
            self.add_bar(j)

        elif kind == "staged":
            if j.state != "staging":
                return
            j.files = m[3]
            j.state = "ready"
            self.set_bar(j, 1.0, "Prêt")
            what = j.files[0].name if len(j.files) == 1 else f"{len(j.files)} fichiers"
            self.add_line(j, f"Prêt : {what}. Clique sur Télécharger pour choisir le dossier.", "ok")

        elif kind == "moved":
            if j.state != "moving":
                return
            files, target = m[3], m[4]
            j.state = "done"
            j.files = []
            self.set_bar(j, 1.0, "Terminé")
            if len(files) == 1:
                self.add_line(j, f"{files[0].name} téléchargé dans {target}", "ok")
            else:
                self.add_line(j, f"{len(files)} fichiers téléchargés dans {target}", "ok")

        elif kind == "move_error":
            if j.state != "moving":
                return
            j.state = "ready"
            self.set_bar(j, 1.0, "Prêt")
            self.add_line(j, f"Erreur : {m[3]}", "err")

        elif kind == "error":
            if j.state not in ("searching", "staging"):
                return
            j.state = "error"
            self.set_bar(j, j.bar_state[0] or 0.0, "Échec")
            self.add_line(j, f"Erreur : {m[3]}", "err")

        self.refresh()


def run():
    try:                            # pour que l'icône s'affiche aussi dans la barre des tâches
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("leeks.downloader")
    except Exception:
        pass
    App().root.mainloop()
